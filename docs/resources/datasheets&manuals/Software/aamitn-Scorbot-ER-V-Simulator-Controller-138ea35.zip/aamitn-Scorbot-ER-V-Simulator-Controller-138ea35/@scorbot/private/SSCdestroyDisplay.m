function SSCdestroyDisplay(display)
% Close and destroy the given display context

    close(display.handle);
    return;

end