function ACLfinish(s)

    fclose(s);
    delete(s);

end
