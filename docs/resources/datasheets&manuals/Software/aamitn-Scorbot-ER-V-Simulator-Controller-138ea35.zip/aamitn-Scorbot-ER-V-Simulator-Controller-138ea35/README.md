# Scorbot-ER-V-Simulator & Controller
This is a Scorbot ER-V+ robotic arm simulation software and physical controller hardware designed by               
Amit Kumar Nandi ©
